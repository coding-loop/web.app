(function () {
  var curso = window.CL.curso;
  curso.questoesPorEtapa = curso.questoesPorEtapa || {};
  curso.questoesPorEtapa["css-modulo-01:3"] = [];
})();
