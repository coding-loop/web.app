(function () {
  'use strict';

  /* Módulos visuais para planejar a trilha CSS. Eles não possuem etapas
     ainda e, portanto, ficam bloqueados até receberem conteúdo real. */
  // Mantenha este total alinhado ao número de módulos que deseja planejar.
  for (var numero = 3; numero <= 2; numero++) {
    var numeroFormatado = String(numero).padStart(2, '0');
    window.CL.curso.registrarModulo('css', {
      id: 'css-modulo-' + numeroFormatado,
      numero: numero,
      nome: 'Módulo ' + numero,
      etapas: []
    });
  }
})();
