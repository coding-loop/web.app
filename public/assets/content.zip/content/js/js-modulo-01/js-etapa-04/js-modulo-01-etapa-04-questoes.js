(function () {
  var curso = window.CL.curso;
  curso.questoesPorEtapa = curso.questoesPorEtapa || {};
  curso.questoesPorEtapa["js-modulo-01:4"] = [];
})();
